# Agent Safety Card – Customer Research Team (Day 18)

**What it does:** answers research questions about a customer database with 4 agents (Planner, Researcher, Writer, Critic).
**Model:** openai/gpt-oss-120b on Groq (judge: qwen/qwen3.8-27b). **Data:** 300 synthetic customers (no real people).

## Tools and permissions (least privilege)
| Agent | Tools | Limits |
|---|---|---|
| Planner, Writer, Critic | none | text only |
| Researcher | `describe_data`, `query_customers`, `count_by` (MCP) | DB opened read-only; one SELECT per call; max 200 rows; 8 steps; 40k-token budget |
| Not available | email, file write, shell, web | sensitive tools would need human approval (default: deny) |

## Measured quality (v2 (with fixes), 20 tasks)
| Metric | Value |
|---|---|
| Success rate (SQL ground truth) | 95% |
| LLM-judge pass rate | 90% |
| Judge agrees with my own grading | not filled in yet |
| Tool-call accuracy | 78% |
| Critic approved a wrong report | 1 tasks |
| Researcher model/API errors | 0 questions (models used: {'openai/gpt-oss-120b': 20}) |
| Avg steps / tokens / latency | 6.3 LLM calls / 3,976 tokens / 40 s (p90 91 s) |

## Security (red-team)
- 11 attacks (jailbreaks, secret theft, data exfiltration, base64-hidden, indirect injection in data, MCP tool poisoning)
- Without guardrails: **2/11** tested attacks worked. With guardrails: **11/11 tested attacks blocked**, 0 not tested (model error).
- Still getting through: none in this test
- Harmless requests wrongly blocked by the input filter: 4%
- Layers: input filter, tool allow-list + least privilege, read-only DB, tool-output sanitizer, output filter, MCP description scanner

## Remaining risks
- **Wrong numbers:** 5% of tasks still fail the ground-truth check; reports must be reviewed before decisions.
- **Filters are pattern-based:** a re-worded or translated attack can pass the input filter and sanitizer; the model is the last line of defence.
- **Non-determinism and model changes:** results vary run to run; a backup model (daily-limit fallback) can behave differently.
- **LLM judge bias:** the judge can be lenient; keep the SQL ground-truth check and spot-check by a human.
- **Availability:** free-tier rate limits make runs slow (40 s average) and can stop for the day.

## Data privacy
- Today: synthetic data only. With real data, customer IDs, cities, ages and free-text `notes` are personal data.
- Prompts and query results are sent to a third-party API (Groq): check the provider's data terms and region before using real data.
- Traces and logs contain query results: restrict access, set a retention period, and do not commit them to Git.
- Mask or drop free-text columns (`notes`) unless needed; never put API keys in code (Colab Secrets only).

## Cost controls
- Measured: $0.0008 per task on the paid tier (≈ $0.85 per 1,000 questions); $0 on the free tier.
- Limits: Researcher max 8 steps, 40k-token budget per run, max 1 Critic revision, rate limiter under 7k tokens/min, daily-limit fallback.
- Monitor: tokens per agent and per run from the OpenTelemetry traces; alert if a run exceeds 2× the average.

## Monitoring and human oversight
- Every run is traced (team → agent → LLM call / tool call) with tokens, model, SQL and status.
- Watch: success rate on the 20-task suite after every change, ungrounded answers, Critic rejections, blocked attacks.
- A human reviews reports before they are used; no agent can send, write or delete anything.
