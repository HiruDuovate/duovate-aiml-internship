# 🤝 Customer Retention Copilot

An agentic AI app that helps retention managers answer: **who is churning, how do customers feel, and what may we offer them?**
Capstone of my AI & ML internship (Day 19 of 20). All customer data is **synthetic**.

![Architecture](architecture.png)

## What it combines
| Part | Technology |
|---|---|
| Multi-agent orchestration | Planner → Researcher → Writer → Critic (LangGraph), max 1 revision |
| Tool calling | Researcher tool loop (own harness: step/token budgets, timeouts, approval policy) |
| MCP server | `server.py` (FastMCP): customers + support messages, **read-only**, SELECT only |
| RAG | Policy documents → MiniLM embeddings → top-k sections with `[source]` citations |
| My trained model as a tool | Day 06 emotion classifier (TF-IDF + Logistic Regression, 6 emotions): re-trained Day 06 baseline on dair-ai/emotion (16,000 tweets), test accuracy 0.863 |
| Memory | Per-user facts in `data/memory.json` |
| Action | `create_ticket` (needs human approval in the UI) |
| Guardrails | Input filter, tool allow-list, read-only DB, tool-output sanitiser, output filter, MCP description scanner |
| Observability | OpenTelemetry spans → `data/otel_spans.jsonl` |
| UI | Gradio chat with live agent steps |

## Setup
### Option 1: Google Colab
Open `day19_capstone.ipynb`, add `GROQ_API_KEY` (and optionally `GEMINI_API_KEY`) in Colab Secrets, Run all. The app cell prints a public link.

### Option 2: on your computer (Python 3.10+)
```bash
cd capstone
pip install -r requirements.txt
cp .env.example .env          # then put your GROQ_API_KEY (and/or GEMINI_API_KEY) in .env
python app.py                 # open http://localhost:7860
```

### Option 3: Docker
```bash
cd capstone
docker build -t retention-copilot .
docker run -p 7860:7860 --env-file .env retention-copilot     # open http://localhost:7860
```

### Configuration
| Variable | Meaning |
|---|---|
| `GROQ_API_KEY` / `GEMINI_API_KEY` | LLM keys (at least one). Free tiers work; the app falls back between models |
| `PORT` | Web port (default 7860) |
| `SHARE` | `1` = also create a public Gradio link |
| `EMOTION_MODEL` | Path to a different emotion model (scikit-learn pipeline, raw text in) |

## Project structure
```
capstone/
├── app.py              # starts the web app
├── core.py             # app logic (generated from the notebook's %%core cells)
├── server.py           # MCP server (read-only database)
├── data/
│   ├── customers.db    # synthetic customers + support messages
│   ├── knowledge_base/ # policy documents for RAG
│   └── emotion_model.joblib
├── requirements.txt, Dockerfile, .env.example
└── architecture.png
```

## Evaluation (Day 18 suite on the capstone, 8 tasks, model (none))
| Metric | Result |
|---|---|
| Success rate (ground truth: SQL / emotion model / policy text) | 62% |
| LLM-judge pass rate | 75% |
| Right tools used | 75% |
| Critic approved a wrong answer | 3 |
| Avg LLM calls / tokens / latency | 9.1 / 10,572 / 100 s (p90 144 s) |
| Cost per question (paid-tier price) | $0.0020 |

| Category | Tasks | Success | Judge | Right tools |
|---|---|---|---|---|
| database | 7.0 | 71% | 86% | 86% |
| emotion | 1.0 | 0% | 0% | 0% |

**Guardrail checks:** 6/6 tested attacks blocked (0 not tested), including prompt injection in
customer notes, in a customer message and in a RAG document, base64-hidden instructions, an unapproved ticket action and MCP tool poisoning.
Harmless requests blocked by the input filter: 1/22.

## Limitations
- Regex guardrails can be bypassed by re-worded or translated attacks; the model is the last line of defence.
- The emotion model was trained on short English tweets; customer messages in other languages are not supported.
- Free-tier rate limits make answers slow (most of the time is waiting for the limiter).
- Synthetic data only. Real customer data would need anonymisation and a data-processing agreement with the LLM provider.
