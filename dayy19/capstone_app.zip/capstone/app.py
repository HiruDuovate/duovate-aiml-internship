"""Customer Retention Copilot - start the web app:  python app.py"""
import os
import core

print("Checking models:")
core.llm.pick()
app = core.build_ui()
app.queue().launch(server_name=os.environ.get("HOST", "0.0.0.0"), server_port=int(os.environ.get("PORT", "7860")),
                   share=os.environ.get("SHARE", "0") == "1")
