import os, re, sys, json, sqlite3
from mcp.server.fastmcp import FastMCP

DB = os.environ.get("CUSTOMER_DB", os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "customers.db"))
mcp = FastMCP("customer-data")
TABLES = {"customers", "messages"}
BLOCKED = re.compile(r"\b(insert|update|delete|drop|alter|create|replace|attach|detach|pragma|vacuum)\b", re.I)

def _connect():
    return sqlite3.connect(f"file:{DB}?mode=ro", uri=True)          # read-only: nothing can be changed

def _columns(table):
    with _connect() as con:
        return [r[1] for r in con.execute(f"PRAGMA table_info({table})")]

@mcp.tool()
def describe_data() -> str:
    "Describe the two tables (customers, messages): columns, row counts and 2 example rows each. Call this first if unsure."
    out = {}
    with _connect() as con:
        for t in sorted(TABLES):
            out[t] = {"columns": _columns(t), "rows": con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0],
                      "sample": con.execute(f"SELECT * FROM {t} LIMIT 2").fetchall()}
    return json.dumps(out, default=str)

@mcp.tool()
def query_db(sql: str, limit: int = 50) -> str:
    "Run ONE read-only SQL SELECT on the tables customers(customer_id, city, age, plan, months_active, monthly_spend_lkr, churned, notes) and messages(message_id, customer_id, date, channel, text). Returns JSON rows."
    q = sql.strip().rstrip(";")
    if ";" in q:
        return "ERROR: only one statement is allowed."
    if not re.match(r"^\s*(select|with)\b", q, re.I) or BLOCKED.search(q):
        return "ERROR: only read-only SELECT queries are allowed."
    try:
        with _connect() as con:
            cur = con.execute(q)
            cols = [d[0] for d in cur.description]
            rows = cur.fetchmany(max(1, min(int(limit), 200)))
    except Exception as e:
        return f"ERROR: {e}"
    return json.dumps({"columns": cols, "rows": rows, "row_count": len(rows)}, default=str)

@mcp.tool()
def count_by(column: str, table: str = "customers") -> str:
    "Count rows grouped by one column, e.g. count_by('city') or count_by('channel', 'messages')."
    if table not in TABLES or column not in _columns(table):
        return f"ERROR: unknown table/column. Tables: {sorted(TABLES)}"
    with _connect() as con:
        rows = con.execute(f'SELECT "{column}", COUNT(*) FROM {table} GROUP BY 1 ORDER BY 2 DESC').fetchall()
    return json.dumps(dict(rows), default=str)

@mcp.tool()
def get_customer(customer_id: str) -> str:
    "Get one customer's profile and all their support messages."
    with _connect() as con:
        con.row_factory = sqlite3.Row
        c = con.execute("SELECT * FROM customers WHERE customer_id = ?", (customer_id,)).fetchone()
        m = con.execute("SELECT message_id, date, channel, text FROM messages WHERE customer_id = ? ORDER BY date", (customer_id,)).fetchall()
    if c is None:
        return f"ERROR: no customer {customer_id}"
    return json.dumps({"profile": dict(c), "messages": [dict(x) for x in m]}, default=str)

if __name__ == "__main__":
    mcp.run()
