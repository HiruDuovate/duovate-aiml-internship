# Data Privacy Policy
## Sharing
Customer phone numbers, emails and notes must never be shared with partners or other third parties.
## Retention
Support messages are kept for 2 years and then deleted.
## AI tools
Only anonymised or synthetic customer data may be sent to external AI services.