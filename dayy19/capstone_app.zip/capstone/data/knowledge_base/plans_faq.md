# Plans FAQ
## Prices
Basic costs 1,500 LKR per month, Standard costs 3,500 LKR per month and Premium costs 7,500 LKR per month.
## Upgrades
Upgrades start at the next billing cycle.
## Cancellation
There is no cancellation fee after 12 months. Customers who cancel before 12 months pay a 2,000 LKR fee.