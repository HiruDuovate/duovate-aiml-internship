# Complaints Policy
## Escalation
Escalate to a manager when a customer complains 2 or more times in 30 days, or when a Premium customer sends an angry message.
## Response time
Every complaint must get a first reply within 24 hours. Urgent tickets must get a reply within 4 hours.
## Ticket priority
Use priority high for anger, medium for sadness or fear, and low for everything else.