# Retention Playbook
## Who is at risk
A customer is at risk if they have been active for less than 12 months, or if they sent an angry or sad message in the last 30 days.
## Offers by plan
Basic customers: offer 15% off for 3 months.
Standard customers: offer a free upgrade to Premium for 1 month.
Premium customers: offer 1 month free and a call from a senior agent.
## Discount limits
Agents can give at most 20% discount without approval. Any discount above 20% needs a manager's approval.
## When not to make an offer
Do not make an offer to customers who churned more than 6 months ago.